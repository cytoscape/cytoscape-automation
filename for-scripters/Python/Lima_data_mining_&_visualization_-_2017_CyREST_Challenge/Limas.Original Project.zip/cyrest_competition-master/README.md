# Battle at The Berrics videos data analysis

This is an analysis submitted to the CyREST competition to create a CyREST workflow orchestrated by Python.

Click [here](https://github.com/lelimat/cyrest_competition/blob/master/Youtube%20data%20analysis%20(The%20Berrics).ipynb) to see the analysis.
